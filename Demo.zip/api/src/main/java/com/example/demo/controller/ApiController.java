package com.example.demo.controller;

import java.io.BufferedReader;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpRequest;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.Image;

@RestController
public class ApiController {

	
//	@PostMapping("/api")
//	public String getApi(Image image) {
//		return image.getImage();
//	}
	
	
	@PostMapping("/api/image")
	public String serveImage(HttpServletRequest request) {
		  StringBuilder buffer = new StringBuilder();
		    BufferedReader reader;
		    String data = null;
			try {
				reader = request.getReader();
				String line;
			    while ((line = reader.readLine()) != null) {
			        buffer.append(line);
			    }
			    data=buffer.toString();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
		     
		return data;
	}
}
