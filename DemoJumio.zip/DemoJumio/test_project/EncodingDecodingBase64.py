import base64

# def EnodeComparison(Actual_String,ExpectedString):
#     encoded= base64.b32encode('Actual_String')
#     print (encoded)
#     if base64.b32encode(Actual_String) == ExpectedString:
#         return True
#     else:
#         return False
#
# EnodeComparison('prateek','cHJhdGVlaw')


# Picture a scenario where you need to retrieve a base64 string and decrypt with a privatekey
def EncodedBase64(Value):
    encodedStr = base64.b64encode(Value)
    print (encodedStr)
    return (encodedStr)

def DecodingBase64(Value):
    DecodedStr = base64.b64decode(Value)
    return (DecodedStr)