import unittest
import requests
import json

def Encode(Value):
    url = "http://localhost:8081/api/image"

    payload = {'image': Value}
    headers = {'content-type': 'application/json'}

    r = requests.post(url, data=json.dumps(payload), headers=headers)
    return (r)

