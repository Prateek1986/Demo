import unittest
from EncodingDecodingBase64 import EncodedBase64
from EncodingDecodingBase64 import DecodingBase64
from RequestEncodingConf import Encode

class TestEncode(unittest.TestCase):


    def test_Encoding(self):
        """
        The actual test.
        Any method which starts with ``test_`` will considered as a test case.
        """
        # Pass the string which needs to be pass in the request body for image tag
        ValuePassed = 'test'
        res = Encode(ValuePassed)
        data = res.json()
        # Extract Encode Value from Json Response for Image Tag
        ActualEncoded = data['image']
        print ActualEncoded

        # Convert the string using the base64 python library
        encodedStr= EncodedBase64(ValuePassed)
        print  encodedStr

        # Comparing the value coming from json response with the value encoded using base 64 library
        self.assertEqual(ActualEncoded,encodedStr)

    def test_Decoding(self):
        """
        The actual test.
        Any method which starts with ``test_`` will considered as a test case.
        """
        # Pass the string which needs to be pass in the request body for image tag
        ValuePassedInJson= 'test'
        res = Encode(ValuePassedInJson)
        data = res.json()
        # Extract Encode Value from Json Response for Image Tag
        ActualEncoded = data['image']
        print ActualEncoded

        # Decode the string back to string
        DecodedStr= DecodingBase64(ActualEncoded)
        print  DecodedStr

        # Comparing the value coming from json response with the value encoded using base 64
        self.assertEqual(ValuePassedInJson,DecodedStr)


if __name__ == '__main__':
    unittest.main()